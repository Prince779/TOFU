import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import ast
plt.rcParams['font.family'] = 'Times New Roman'

# Function to process each file and return a DataFrame
def process_file(filename, trials):
    df = pd.read_csv(filename)
    reputation_data = pd.DataFrame()

    # Extract reputation arrays and store them in a new DataFrame
    for i in range(len(df)):
        reputation_array = ast.literal_eval(df.iloc[i]['Reputation'])
        temp_df = pd.DataFrame({'UAV': [f'UAV {i+1}']*trials, 'Trial': range(1, trials + 1), 'Reputation': reputation_array})
        reputation_data = pd.concat([reputation_data, temp_df], ignore_index=True)

    # Calculate mean reputation for each trial
    mean_reputation = reputation_data.groupby('Trial')['Reputation'].mean().values
    mean_df = pd.DataFrame({'UAV': ['Mean']*trials, 'Trial': range(1, trials + 1), 'Reputation': mean_reputation})

    # Append the mean data to the reputation_data DataFrame
    reputation_data = pd.concat([reputation_data, mean_df], ignore_index=True)

    return reputation_data

# File names and corresponding number of trials
files_and_trials = [('uav_data_rept_5.csv', 5), ('uav_data_rept_7.csv', 7), ('uav_data_rept_10.csv', 10)]

# Create a dummy plot to generate legend handles and labels
dummy_df = process_file(files_and_trials[0][0], files_and_trials[0][1])
dummy_plot = sns.pointplot(data=dummy_df, x='Trial', y='Reputation', hue='UAV', marker='o', dodge=True)
handles, labels = dummy_plot.get_legend_handles_labels()
plt.close()  # Close the dummy plot

# Calculate width ratios based on the number of trials
width_ratios = [trials for _, trials in files_and_trials]

# Create subplots with specified width ratios
fig, axes = plt.subplots(1, 3, figsize=(16.5, 5), sharey=True, gridspec_kw={'width_ratios': width_ratios})

# Plot data for each file
for ax, (filename, trials), label in zip(axes, files_and_trials, ['(a)', '(b)', '(c)']):
    reputation_data = process_file(filename, trials)
    
    # Plot each UAV separately with thinner lines, except for the mean
    for uav in reputation_data['UAV'].unique():
        subset = reputation_data[reputation_data['UAV'] == uav]
        if uav == 'Mean':
            sns.pointplot(data=subset, x='Trial', y='Reputation', marker='o', dodge=True, ax=ax, linewidth=2.5)
        else:
            sns.pointplot(data=subset, x='Trial', y='Reputation', marker='o', dodge=True, ax=ax, linewidth=1.3)
    
    ax.set_xlabel('Trial', fontsize=18)
    ax.set_ylabel('Reputation', fontsize=18)
    ax.grid(True)

    # Set x-tick and y-tick parameters
    ax.xaxis.set_tick_params(labelsize=14)  # Set fontsize for x-ticks
    ax.yaxis.set_tick_params(labelsize=14)  # Set fontsize for y-ticks

    # Add subplot label
    ax.text(0.5, -0.22, label, transform=ax.transAxes, fontsize=16, ha='center')

# Create a single legend for the entire figure
fig.legend(handles, labels, bbox_to_anchor=(0.5, 1.02), loc='upper center', ncol=6, fontsize='x-large')

plt.tight_layout(rect=[0, 0, 1, 0.95])  # Adjust layout to make room for the legend
plt.savefig('reputation_vs_trials.pdf', format='pdf', bbox_inches='tight')
plt.show()
