import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import ast

# Load the data
df_5_trials = pd.read_csv('uav_data_rept_5.csv')
df_7_trials = pd.read_csv('uav_data_rept_7.csv')
df_10_trials = pd.read_csv('uav_data_rept_10.csv')

def sum_reputations(df):
    num_uavs = len(df)
    num_trials = len(ast.literal_eval(df.iloc[0]['Reputation']))
    summed_reputations = np.zeros(num_trials)

    for i in range(num_uavs):
        reputation_array = ast.literal_eval(df.iloc[i]['Reputation'])
        summed_reputations += np.array(reputation_array)

    return summed_reputations

# Calculate summed reputations
summed_reputations_5 = sum_reputations(df_5_trials)
summed_reputations_7 = sum_reputations(df_7_trials)
summed_reputations_10 = sum_reputations(df_10_trials)

# Plotting
plt.figure(figsize=(12, 6))

# Plot for 5 trials
plt.plot(range(1, len(summed_reputations_5) + 1), summed_reputations_5, marker='o', linestyle='-', label='5 Trials', color='blue')

# Plot for 7 trials
plt.plot(range(1, len(summed_reputations_7) + 1), summed_reputations_7, marker='o', linestyle='-', label='7 Trials', color='green')

# Plot for 10 trials
plt.plot(range(1, len(summed_reputations_10) + 1), summed_reputations_10, marker='o', linestyle='-', label='10 Trials', color='red')

# Adding labels and title
plt.xlabel('Trial')
plt.ylabel('Summed Reputation')
plt.legend()
plt.grid(True)

plt.ylim(0, 800)

# Show the plot
plt.show()
