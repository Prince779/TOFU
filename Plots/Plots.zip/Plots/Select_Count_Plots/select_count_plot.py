# prompt: plot a scatter plot of residual energy vs select count for all the 3 dataframes, uav_dfs[0], [1], [2]. each with different color

import matplotlib.pyplot as plt
import pandas as pd
from matplotlib import rcParams
import os

directory = '.'
uav_dfs = []
for filename in os.listdir(directory):
  if filename.endswith(".csv"):
    filepath = os.path.join(directory, filename)
    df = pd.read_csv(filepath)
    uav_dfs.append(df)

print(len(uav_dfs))

plt.rcParams['font.family'] = 'Times New Roman'

# Create a figure and a set of subplots
fig, axes = plt.subplots(1, 3, figsize=(15, 5))  # 1 row, 3 columns

# Plot 1: Residual Energy vs Select Count
axes[0].scatter(uav_dfs[0]['Residual Energy'], uav_dfs[0]['Select Count'], color='blue')
axes[0].scatter(uav_dfs[1]['Residual Energy'], uav_dfs[1]['Select Count'], color='red')
axes[0].scatter(uav_dfs[2]['Residual Energy'], uav_dfs[2]['Select Count'], color='green')
axes[0].set_xlabel('Residual energy (Watt-hr)', fontsize=18)
axes[0].set_ylabel('Tasks served', fontsize=18)
axes[0].text(0.5, -0.25, '(a)', transform=axes[0].transAxes, fontsize=18, va='top', ha='center')

# Plot 2: Clock Speed vs Select Count
axes[1].scatter(uav_dfs[0]['Clock Speed'], uav_dfs[0]['Select Count'], color='blue', label='$1 \leq M_t \leq 4$')
axes[1].scatter(uav_dfs[1]['Clock Speed'], uav_dfs[1]['Select Count'], color='red', label='$6 \leq M_t \leq 10$')
axes[1].scatter(uav_dfs[2]['Clock Speed'], uav_dfs[2]['Select Count'], color='green', label='$12 \leq M_t \leq 16$')
axes[1].set_xlabel('Clock speed (MHz)', fontsize=18)
# axes[1].set_ylabel('Select count', fontsize=18)
axes[1].text(0.5, -0.25, '(b)', transform=axes[1].transAxes, fontsize=18, va='top', ha='center')

# Plot 3: Memory vs Select Count
axes[2].scatter(uav_dfs[0]['Memory'], uav_dfs[0]['Select Count'], color='blue')
axes[2].scatter(uav_dfs[1]['Memory'], uav_dfs[1]['Select Count'], color='red')
axes[2].scatter(uav_dfs[2]['Memory'], uav_dfs[2]['Select Count'], color='green')
axes[2].set_xlabel('Memory (GB)', fontsize=18)
# axes[2].set_ylabel('Select count', fontsize=18)
axes[2].text(0.5, -0.25, '(c)', transform=axes[2].transAxes, fontsize=18, va='top', ha='center')

# Set xticks and yticks size to 14
for ax in axes:
    ax.tick_params(axis='both', which='major', labelsize=14)

# Single legend for all plots
handles, labels = axes[1].get_legend_handles_labels()  # Get handles and labels from one of the plots
fig.legend(handles, labels, loc='upper center', ncol=3, fontsize='x-large')  # Place legend above the plots

# Adjust layout and display the plot
plt.tight_layout(rect=[0, 0.03, 1, 0.9])  # Adjust layout to accommodate the legend

plt.savefig('trials_served_vs_resource.pdf', format='pdf', bbox_inches='tight')
plt.show()
