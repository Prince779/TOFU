import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
plt.rcParams['font.family'] = 'Times New Roman'

# Load the CSV file
df = pd.read_csv('uav_data_trails_100.csv')

# Ensure the relevant columns are numeric
df['Residual Energy'] = pd.to_numeric(df['Residual Energy'], errors='coerce')
df['Avg Power Consumption'] = pd.to_numeric(df['Avg Power Consumption'], errors='coerce')
df['Select Count'] = pd.to_numeric(df['Select Count'], errors='coerce')

# Drop rows with NaN values in any of the relevant columns
df = df.dropna(subset=['Residual Energy', 'Avg Power Consumption', 'Select Count'])

# Plot the scatter plot with color coding for Select Count
plt.figure(figsize=(7.5, 6))
scatter = plt.scatter(df['Avg Power Consumption'], df['Residual Energy'], c=df['Select Count'], cmap='viridis', s=100, alpha=0.7, edgecolors='w', linewidth=0.5)

# Modify the color bar to set the label and its fontsize
colorbar = plt.colorbar(scatter)
colorbar.set_label('Trials Served', fontsize=18)
colorbar.ax.tick_params(labelsize=14)  # Set fontsize for colorbar ticks

plt.xlabel('Average power consumption (Watts)', fontsize=18)
plt.ylabel('Residual energy (Watt-hr)', fontsize=18)

# Set fontsize for x-ticks and y-ticks
plt.xticks(fontsize=14)
plt.yticks(fontsize=14)
plt.grid(True)

plt.savefig('scatter_plot_energy_vs_power.pdf', format='pdf', bbox_inches='tight')
plt.show()