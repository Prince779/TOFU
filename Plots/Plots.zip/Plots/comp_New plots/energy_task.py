import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from scipy import stats
from matplotlib.ticker import FuncFormatter
from mpl_toolkits.axes_grid1.inset_locator import inset_axes


plt.rcParams['font.family'] = 'Times New Roman'

# Load the CSV file
# df = pd.read_csv('modified_task_num_tasks_energy.csv')
df = pd.read_csv(r'C:\Prince\Research\Trust Evaluation in FU_Serve\Trust Major\Codes\comp\modified_task_num_tasks_energy.csv')


# Get unique data tasks
num_taskss = df['num_tasks'].unique()

# Initialize lists to store results
avg_energy_trust = []
avg_energy_detto = []
avg_energy_dpto = []
avg_energy_soa = []
ci_trust = []
ci_detto = []
ci_dpto = []
ci_soa = []

# Compute the mean, standard deviation, and 95% confidence interval for each data task
for task in num_taskss:
    subset = df[df['num_tasks'] == task]
    
    # Trust
    mean_trust = subset['avg_energy_trust'].mean()
    std_trust = subset['avg_energy_trust'].std()
    n_trust = len(subset)
    ci_trust.append(stats.norm.interval(0.95, loc=mean_trust, scale=std_trust/np.sqrt(n_trust)))
    avg_energy_trust.append(mean_trust)
    
    # DETTO
    mean_detto = subset['avg_energy_detto'].mean()
    std_detto = subset['avg_energy_detto'].std()
    n_detto = len(subset)
    ci_detto.append(stats.norm.interval(0.95, loc=mean_detto, scale=std_detto/np.sqrt(n_detto)))
    avg_energy_detto.append(mean_detto)
    
    # DPTO
    mean_dpto = subset['avg_energy_dpto'].mean()
    std_dpto = subset['avg_energy_dpto'].std()
    n_dpto = len(subset)
    ci_dpto.append(stats.norm.interval(0.95, loc=mean_dpto, scale=std_dpto/np.sqrt(n_dpto)))
    avg_energy_dpto.append(mean_dpto)

    # SOA
    mean_soa = subset['avg_energy_soa'].mean()
    std_soa = subset['avg_energy_soa'].std()
    n_soa = len(subset)
    ci_soa.append(stats.norm.interval(0.95, loc=mean_soa, scale=std_soa/np.sqrt(n_soa)))
    avg_energy_soa.append(mean_soa)

# Convert lists to numpy arrays for plotting
num_taskss = np.array(num_taskss)
avg_energy_trust = np.array(avg_energy_trust)
avg_energy_detto = np.array(avg_energy_detto)
avg_energy_dpto = np.array(avg_energy_dpto)
avg_energy_soa = np.array(avg_energy_soa)
ci_trust = np.array(ci_trust)
ci_detto = np.array(ci_detto)
ci_dpto = np.array(ci_dpto)
ci_soa = np.array(ci_soa)
# Plotting
fig, ax = plt.subplots(figsize=(8, 6))

bar_width = 0.18
index = np.arange(len(num_taskss))

# Plot bars for each type of energy with error bars for confidence intervals


bars_trust = ax.bar(index - 1.5 * bar_width, avg_energy_trust, bar_width,
                    yerr=[(avg_energy_trust - ci_trust[:, 0]), (ci_trust[:, 1] - avg_energy_trust)],
                    label='TOFU', capsize=5, alpha=0.7, color='khaki', hatch='\\', edgecolor='black', zorder=3)

bars_detto = ax.bar(index - 0.5 * bar_width, avg_energy_detto, bar_width,
                    yerr=[(avg_energy_detto - ci_detto[:, 0]), (ci_detto[:, 1] - avg_energy_detto)],
                    label='DETTO', capsize=5, alpha=0.7, color='darkolivegreen', hatch='.', edgecolor='black', zorder=3)

bars_dpto = ax.bar(index + 0.5 * bar_width, avg_energy_dpto, bar_width,
                   yerr=[(avg_energy_dpto - ci_dpto[:, 0]), (ci_dpto[:, 1] - avg_energy_dpto)],
                   label='DPTO', capsize=5, alpha=0.7, color='darkgreen', hatch='+', edgecolor='black', zorder=3)

bars_soa = ax.bar(index + 1.5 * bar_width, avg_energy_soa, bar_width,
                  yerr=[(avg_energy_soa - ci_soa[:, 0]), (ci_soa[:, 1] - avg_energy_soa)],
                  label='SOA', capsize=5, alpha=0.7, color='mediumseagreen', hatch='/', edgecolor='black', zorder=3)


from mpl_toolkits.axes_grid1.inset_locator import inset_axes

# === Inset for Task Count 1 ===
axins1 = inset_axes(ax, width="38%", height="55%",
                    bbox_to_anchor=(-0.18, 0.06, 0.4, 0.4),
                    bbox_transform=ax.transAxes)

x1 = np.arange(1)
axins1.bar(x1 - 1.5 * bar_width, avg_energy_trust[:1], bar_width,
           yerr=[(avg_energy_trust[:1] - ci_trust[:1, 0]), (ci_trust[:1, 1] - avg_energy_trust[:1])],
           capsize=5, alpha=0.7, color='khaki', hatch='\\', edgecolor='black')
axins1.bar(x1 - 0.5 * bar_width, avg_energy_detto[:1], bar_width,
           yerr=[(avg_energy_detto[:1] - ci_detto[:1, 0]), (ci_detto[:1, 1] - avg_energy_detto[:1])],
           capsize=5, alpha=0.7, color='darkolivegreen', hatch='.', edgecolor='black')
axins1.bar(x1 + 0.5 * bar_width, avg_energy_dpto[:1], bar_width,
           yerr=[(avg_energy_dpto[:1] - ci_dpto[:1, 0]), (ci_dpto[:1, 1] - avg_energy_dpto[:1])],
           capsize=5, alpha=0.7, color='darkgreen', hatch='+', edgecolor='black')
axins1.bar(x1 + 1.5 * bar_width, avg_energy_soa[:1], bar_width,
           yerr=[(avg_energy_soa[:1] - ci_soa[:1, 0]), (ci_soa[:1, 1] - avg_energy_soa[:1])],
           capsize=5, alpha=0.7, color='mediumseagreen', hatch='/', edgecolor='black')
axins1.set_xticks(x1)
axins1.set_xticklabels([num_taskss[0]])
axins1.set_ylim(0.82, 0.86)
# axins1.set_title("Zoom: " + str(num_taskss[0]), fontsize=8)

# === Inset for Task Count 2 ===
axins2 = inset_axes(ax, width="38%", height="55%",
                    bbox_to_anchor=(0.03, 0.35, 0.4, 0.4),
                    bbox_transform=ax.transAxes)

x2 = np.arange(1, 2)
axins2.bar(x2 - 1.5 * bar_width, avg_energy_trust[1:2], bar_width,
           yerr=[(avg_energy_trust[1:2] - ci_trust[1:2, 0]), (ci_trust[1:2, 1] - avg_energy_trust[1:2])],
           capsize=5, alpha=0.7, color='khaki', hatch='\\', edgecolor='black')
axins2.bar(x2 - 0.5 * bar_width, avg_energy_detto[1:2], bar_width,
           yerr=[(avg_energy_detto[1:2] - ci_detto[1:2, 0]), (ci_detto[1:2, 1] - avg_energy_detto[1:2])],
           capsize=5, alpha=0.7, color='darkolivegreen', hatch='.', edgecolor='black')
axins2.bar(x2 + 0.5 * bar_width, avg_energy_dpto[1:2], bar_width,
           yerr=[(avg_energy_dpto[1:2] - ci_dpto[1:2, 0]), (ci_dpto[1:2, 1] - avg_energy_dpto[1:2])],
           capsize=5, alpha=0.7, color='darkgreen', hatch='+', edgecolor='black')
axins2.bar(x2 + 1.5 * bar_width, avg_energy_soa[1:2], bar_width,
           yerr=[(avg_energy_soa[1:2] - ci_soa[1:2, 0]), (ci_soa[1:2, 1] - avg_energy_soa[1:2])],
           capsize=5, alpha=0.7, color='mediumseagreen', hatch='/', edgecolor='black')
axins2.set_xticks(x2)
axins2.set_xticklabels([num_taskss[1]])
axins2.set_ylim(0.79, 0.81)
# axins2.set_title("Zoom: " + str(num_taskss[1]), fontsize=8)

# === Inset for Task Count 3 ===
axins3 = inset_axes(ax, width="38%", height="55%",
                    bbox_to_anchor=(0.25, 0.52, 0.4, 0.4),
                    bbox_transform=ax.transAxes)

x3 = np.arange(2, 3)
axins3.bar(x3 - 1.5 * bar_width, avg_energy_trust[2:3], bar_width,
           yerr=[(avg_energy_trust[2:3] - ci_trust[2:3, 0]), (ci_trust[2:3, 1] - avg_energy_trust[2:3])],
           capsize=5, alpha=0.7, color='khaki', hatch='\\', edgecolor='black')
axins3.bar(x3 - 0.5 * bar_width, avg_energy_detto[2:3], bar_width,
           yerr=[(avg_energy_detto[2:3] - ci_detto[2:3, 0]), (ci_detto[2:3, 1] - avg_energy_detto[2:3])],
           capsize=5, alpha=0.7, color='darkolivegreen', hatch='.', edgecolor='black')
axins3.bar(x3 + 0.5 * bar_width, avg_energy_dpto[2:3], bar_width,
           yerr=[(avg_energy_dpto[2:3] - ci_dpto[2:3, 0]), (ci_dpto[2:3, 1] - avg_energy_dpto[2:3])],
           capsize=5, alpha=0.7, color='darkgreen', hatch='+', edgecolor='black')
axins3.bar(x3 + 1.5 * bar_width, avg_energy_soa[2:3], bar_width,
           yerr=[(avg_energy_soa[2:3] - ci_soa[2:3, 0]), (ci_soa[2:3, 1] - avg_energy_soa[2:3])],
           capsize=5, alpha=0.7, color='mediumseagreen', hatch='/', edgecolor='black')
axins3.set_xticks(x3)
axins3.set_xticklabels([num_taskss[2]])
axins3.set_ylim(0.785, 0.81)
# axins3.set_title("Zoom: " + str(num_taskss[2]), fontsize=8)

# Optional: mark the region on main plot if relevant
# ax.indicate_inset_zoom(axins3)

# Custom formatter for y-axis to limit decimal places
formatter = FuncFormatter(lambda y, _: '{:.2f}'.format(y))
ax.yaxis.set_major_formatter(formatter)

# Formatting the plot
# ax.set_ylim(0.78, 0.85)
ax.set_xlabel('Number of tasks', fontsize=24)
ax.set_ylabel('Energy consumed per task (Watt-hr)', fontsize=24)
ax.set_xticks(index)
ax.set_xticklabels(num_taskss, fontsize=24)
ax.tick_params(axis='y', labelsize=24)
ax.grid(zorder=0)
ax.legend(loc='upper right',fontsize='xx-large')

plt.tight_layout()
# plt.savefig('average_energy_plot_num_tasks.pdf', format='pdf', bbox_inches='tight')
plt.savefig(r'C:\Prince\Research\Trust Evaluation in FU_Serve\Trust Major\Codes\comp\average_energy_plot_num_tasks.pdf', format='pdf', bbox_inches='tight')

plt.show()
