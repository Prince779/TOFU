import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from scipy import stats
from mpl_toolkits.axes_grid1.inset_locator import inset_axes

plt.rcParams['font.family'] = 'Times New Roman'

# Load the CSV file
# df = pd.read_csv('modified_task_data_volume_energy.csv')
df = pd.read_csv(r'C:\Prince\Research\Trust Evaluation in FU_Serve\Trust Major\Codes\comp\modified_task_data_volume_energy.csv')


# Get unique data volumes
data_volumes = df['data_volume'].unique()

# Initialize lists to store results
avg_energy_trust = []
avg_energy_detto = []
avg_energy_dpto = []
avg_energy_soa = []
ci_trust = []
ci_detto = []
ci_dpto = []
ci_soa = []
# Compute the mean, standard deviation, and 95% confidence interval for each data volume
for volume in data_volumes:
    subset = df[df['data_volume'] == volume]
    
    # Trust
    mean_trust = subset['avg_energy_trust'].mean()
    std_trust = subset['avg_energy_trust'].std()
    n_trust = len(subset)
    ci_trust.append(stats.norm.interval(0.95, loc=mean_trust, scale=std_trust/np.sqrt(n_trust)))
    avg_energy_trust.append(mean_trust)
    
    # DETTO
    mean_detto = subset['avg_energy_detto'].mean()
    std_detto = subset['avg_energy_detto'].std()
    n_detto = len(subset)
    ci_detto.append(stats.norm.interval(0.95, loc=mean_detto, scale=std_detto/np.sqrt(n_detto)))
    avg_energy_detto.append(mean_detto)
    
    # DPTO
    mean_dpto = subset['avg_energy_dpto'].mean()
    std_dpto = subset['avg_energy_dpto'].std()
    n_dpto = len(subset)
    ci_dpto.append(stats.norm.interval(0.95, loc=mean_dpto, scale=std_dpto/np.sqrt(n_dpto)))
    avg_energy_dpto.append(mean_dpto)

     # SOA
    mean_soa = subset['avg_energy_soa'].mean()
    std_soa = subset['avg_energy_soa'].std()
    n_soa = len(subset)
    ci_soa.append(stats.norm.interval(0.95, loc=mean_soa, scale=std_soa/np.sqrt(n_soa)))
    avg_energy_soa.append(mean_soa)

# Convert lists to numpy arrays for plotting
data_volumes = np.array(data_volumes)
avg_energy_trust = np.array(avg_energy_trust)
avg_energy_detto = np.array(avg_energy_detto)
avg_energy_dpto = np.array(avg_energy_dpto)
avg_energy_soa = np.array(avg_energy_soa)
ci_trust = np.array(ci_trust)
ci_detto = np.array(ci_detto)
ci_dpto = np.array(ci_dpto)
ci_soa = np.array(ci_soa)

# Plotting
fig, ax = plt.subplots(figsize=(8, 6))

bar_width = 0.2
index = np.arange(len(data_volumes))

# Plot bars for each type of energy with error bars for confidence intervals
bars_trust = ax.bar(index - 1.5 * bar_width, avg_energy_trust, bar_width,
                    yerr=[(avg_energy_trust - ci_trust[:, 0]), (ci_trust[:, 1] - avg_energy_trust)],
                    label='TOFU', capsize=5, alpha=0.7, color='khaki', hatch='\\', edgecolor='black', zorder=3)

bars_detto = ax.bar(index - 0.5 * bar_width, avg_energy_detto, bar_width,
                    yerr=[(avg_energy_detto - ci_detto[:, 0]), (ci_detto[:, 1] - avg_energy_detto)],
                    label='DETTO', capsize=5, alpha=0.7, color='darkolivegreen', hatch='.', edgecolor='black', zorder=3)

bars_dpto = ax.bar(index + 0.5 * bar_width, avg_energy_dpto, bar_width,
                   yerr=[(avg_energy_dpto - ci_dpto[:, 0]), (ci_dpto[:, 1] - avg_energy_dpto)],
                   label='DPTO', capsize=5, alpha=0.7, color='darkgreen', hatch='+', edgecolor='black', zorder=3)

bars_soa = ax.bar(index + 1.5 * bar_width, avg_energy_soa, bar_width,
                  yerr=[(avg_energy_soa - ci_soa[:, 0]), (ci_soa[:, 1] - avg_energy_soa)],
                  label='SOA', capsize=5, alpha=0.7, color='mediumseagreen', hatch='/', edgecolor='black', zorder=3)

# Formatting the plot
ax.set_xlabel('Data volume (MB)', fontsize=24)
ax.set_ylabel('Energy consumed per task (Watt-hr)', fontsize=24)
# ax.set_ylim(0.3, 1.05)
ax.set_xticks(index)
ax.set_xticklabels(data_volumes, fontsize=24)
ax.tick_params(axis='y', labelsize=24)
ax.grid(zorder=0)
ax.legend(fontsize='xx-large')

# Inset for the first data volume
ax_inset1 = inset_axes(ax, width="40%", height="60%", bbox_to_anchor=(-0.14, 0.20, 0.35, 0.35), bbox_transform=ax.transAxes)

# Data for the first volume
first_index = np.arange(1)
x_inset1 = first_index
x_inset_trust1 = x_inset1 - bar_width
x_inset_detto1 = x_inset1
x_inset_dpto1 = x_inset1 + bar_width
x_inset_soa1 = x_inset1 + 2 * bar_width


ax_inset1.bar(x_inset_trust1, avg_energy_trust[:1], bar_width,
             yerr=[(avg_energy_trust[:1] - ci_trust[:1,0]), (ci_trust[:1,1] - avg_energy_trust[:1])],
             label='TOFU', capsize=5, alpha=0.7, color='khaki', hatch='\\', edgecolor='black')

ax_inset1.bar(x_inset_detto1, avg_energy_detto[:1], bar_width,
             yerr=[(avg_energy_detto[:1] - ci_detto[:1,0]), (ci_detto[:1,1] - avg_energy_detto[:1])],
             label='DETTO', capsize=5, alpha=0.7, color='darkolivegreen', hatch='.', edgecolor='black')

ax_inset1.bar(x_inset_dpto1, avg_energy_dpto[:1], bar_width,
             yerr=[(avg_energy_dpto[:1] - ci_dpto[:1,0]), (ci_dpto[:1,1] - avg_energy_dpto[:1])],
             label='DPTO', capsize=5, alpha=0.7, color='darkgreen', hatch='+', edgecolor='black')
ax_inset1.bar(x_inset_soa1, avg_energy_soa[:1], bar_width,
             yerr=[(avg_energy_soa[:1] - ci_soa[:1,0]), (ci_soa[:1,1] - avg_energy_soa[:1])],
             label='SOA', capsize=5, alpha=0.7, color='mediumseagreen', hatch='/', edgecolor='black')

# Formatting the inset plot
ax_inset1.set_xticks(x_inset1)
ax_inset1.set_xticklabels(data_volumes[:1])
ax_inset1.set_ylim(0.338, 0.343)
ax_inset1.tick_params(axis='y')
# ax_inset1.yaxis.set_visible(False)  # Hide y-axis ticks and labels




# Inset for the second data volume
ax_inset2 = inset_axes(ax, width="40%", height="60%", bbox_to_anchor=(0.055, 0.35, 0.35, 0.35), bbox_transform=ax.transAxes)

# Data for the second volume
second_index = np.arange(1, 2)
x_inset2 = second_index
x_inset_trust2 = x_inset2 - bar_width
x_inset_detto2 = x_inset2
x_inset_dpto2 = x_inset2 + bar_width
x_inset_soa2 = x_inset2 + 2 * bar_width


ax_inset2.bar(x_inset_trust2, avg_energy_trust[1:2], bar_width,
             yerr=[(avg_energy_trust[1:2] - ci_trust[1:2,0]), (ci_trust[1:2,1] - avg_energy_trust[1:2])],
             label='TOFU', capsize=5, alpha=0.7, color='khaki', hatch='\\', edgecolor='black')

ax_inset2.bar(x_inset_detto2, avg_energy_detto[1:2], bar_width,
             yerr=[(avg_energy_detto[1:2] - ci_detto[1:2,0]), (ci_detto[1:2,1] - avg_energy_detto[1:2])],
             label='DETTO', capsize=5, alpha=0.7, color='darkolivegreen', hatch='.', edgecolor='black')

ax_inset2.bar(x_inset_dpto2, avg_energy_dpto[1:2], bar_width,
             yerr=[(avg_energy_dpto[1:2] - ci_dpto[1:2,0]), (ci_dpto[1:2,1] - avg_energy_dpto[1:2])],
             label='DPTO', capsize=5, alpha=0.7, color='darkgreen', hatch='+', edgecolor='black')

ax_inset2.bar(x_inset_soa2, avg_energy_soa[1:2], bar_width,
              yerr=[(avg_energy_soa[1:2] - ci_soa[1:2, 0]), (ci_soa[1:2, 1] - avg_energy_soa[1:2])],
              label='SOA', capsize=5, alpha=0.7, color='mediumseagreen', hatch='/', edgecolor='black')


# Formatting the inset plot
ax_inset2.set_xticks(x_inset2)
ax_inset2.set_xticklabels(data_volumes[1:2])
ax_inset2.set_ylim(0.5, 0.52)
ax_inset2.tick_params(axis='y')
# ax_inset2.yaxis.set_visible(False)  # Hide y-axis ticks and labels

# Data for the third volume
third_index = np.arange(2, 3)  # Index for the third volume
x_inset3 = third_index
x_inset_trust3 = x_inset3 - bar_width
x_inset_detto3 = x_inset3
x_inset_dpto3 = x_inset3 + bar_width
x_inset_soa3 = x_inset3 + 2 * bar_width


ax_inset3 = inset_axes(ax, width="40%", height="60%", bbox_to_anchor=(0.25, 0.55, 0.35, 0.35), bbox_transform=ax.transAxes)

ax_inset3.bar(x_inset_trust3, avg_energy_trust[2:3], bar_width,
             yerr=[(avg_energy_trust[2:3] - ci_trust[2:3,0]), (ci_trust[2:3,1] - avg_energy_trust[2:3])],
             label='TOFU', capsize=5, alpha=0.7, color='khaki', hatch='\\', edgecolor='black')

ax_inset3.bar(x_inset_detto3, avg_energy_detto[2:3], bar_width,
             yerr=[(avg_energy_detto[2:3] - ci_detto[2:3,0]), (ci_detto[2:3,1] - avg_energy_detto[2:3])],
             label='DETTO', capsize=5, alpha=0.7, color='darkolivegreen', hatch='.', edgecolor='black')

ax_inset3.bar(x_inset_dpto3, avg_energy_dpto[2:3], bar_width,
             yerr=[(avg_energy_dpto[2:3] - ci_dpto[2:3,0]), (ci_dpto[2:3,1] - avg_energy_dpto[2:3])],
             label='DPTO', capsize=5, alpha=0.7, color='darkgreen', hatch='+', edgecolor='black')

ax_inset3.bar(x_inset_soa3, avg_energy_soa[2:3], bar_width,
              yerr=[(avg_energy_soa[2:3] - ci_soa[2:3, 0]), (ci_soa[2:3, 1] - avg_energy_soa[2:3])],
              label='SOA', capsize=5, alpha=0.7, color='mediumseagreen', hatch='/', edgecolor='black')


# Formatting the inset plot
ax_inset3.set_xticks(x_inset3)
ax_inset3.set_xticklabels(data_volumes[2:3])
ax_inset3.set_ylim(0.67, 0.685)
ax_inset3.tick_params(axis='y')
# ax_inset3.yaxis.set_visible(False)  # Hide y-axis ticks and labels

plt.tight_layout()
plt.savefig(r'C:\Prince\Research\Trust Evaluation in FU_Serve\Trust Major\Codes\comp\average_energy_plot_data_volume.pdf', format='pdf', bbox_inches='tight')

plt.show()
