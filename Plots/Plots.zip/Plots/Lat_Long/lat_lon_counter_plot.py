import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
plt.rcParams['font.family'] = 'Times New Roman'

# Function to process each file and return the grouped DataFrame
def process_file(filename):
    df = pd.read_csv(filename)
    # Group by the unique columns and calculate the mean of 'eligible_fraction'
    grouped_df = df.groupby(['num_uav', 'max_lat', 'max_long', 'area', 'num_tasks'], as_index=False).mean()
    # Drop the 'iteration' column
    grouped_df = grouped_df.drop(columns=['iteration'])
    return grouped_df

# Process both CSV files
df_10 = process_file('eligible_fraction_10.csv')
df_20 = process_file('eligible_fraction_20.csv')

# Function to create the contour plot
def create_contour_plot(df, ax, title, label):
    # Pivot the table to create a grid for contour plot
    pivot_table = df.pivot(index='max_lat', columns='max_long', values='eligible_fraction')
    # Create meshgrid for plotting
    X, Y = np.meshgrid(pivot_table.columns.values, pivot_table.index.values)
    Z = pivot_table.values
    # Create contour plot
    cp = ax.contourf(X/1000, Y/1000, Z, cmap='viridis')
    # ax.set_title(title, fontsize=18)
    ax.set_xlabel('Maximum Longitude (km)', fontsize=24)
    ax.set_ylabel('Maximum Latitude (km)', fontsize=24)
    # Set x-ticks and y-ticks fontsize
    ax.tick_params(axis='both', which='major', labelsize=24)
    # Add subplot label
    ax.text(0.5, -0.15, label, transform=ax.transAxes, fontsize=22, ha='center')
    return cp

# Create subplots
fig, axes = plt.subplots(1, 2, figsize=(18, 8), sharey=True)

# Create contour plots for both dataframes
cp1 = create_contour_plot(df_10, axes[0], 'Eligible Fraction (10 Iterations)', '(a)')
cp2 = create_contour_plot(df_20, axes[1], 'Eligible Fraction (20 Iterations)', '(b)')

# Create a single horizontal color bar for both plots at the top center
colorbar = fig.colorbar(cp1, ax=axes, orientation='vertical', fraction=0.02, pad=0.04)
colorbar.set_label('Fraction of UAVs eligible', fontsize=24)
colorbar.ax.tick_params(labelsize=24)  # Set fontsize for colorbar ticks

# Adjust layout and display the plots
plt.tight_layout(rect=[0, 0, 0.87, 1])

plt.savefig('lat_long_eligibility.pdf', format='pdf', bbox_inches='tight')
plt.show()
