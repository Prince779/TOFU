import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from scipy.stats import sem, t
from mpl_toolkits.axes_grid1.inset_locator import inset_axes
plt.rcParams['font.family'] = 'Times New Roman'

# Load the CSV file into a DataFrame
df = pd.read_csv('energy_consumption_data_volume.csv')

# Group the data by data_volume_range
grouped = df.groupby('data_volume_range')

# Initialize lists to store means and confidence intervals
data_volume_range = []
total_energy_means = []
total_energy_cis = []
service_energy_means = []
service_energy_cis = []
task_energy_means = []
task_energy_cis = []

confidence_level = 0.95
num_iterations = 100  # Assuming 100 iterations per group
degrees_freedom = num_iterations - 1

# Calculate means and confidence intervals for each group
for name, group in grouped:
    data_volume_range.append(name)
    
    total_mean = group['total_energy'].mean()
    total_sem = sem(group['total_energy'])
    total_ci = total_sem * t.ppf((1 + confidence_level) / 2, degrees_freedom)
    
    service_mean = group['service_energy'].mean()
    service_sem = sem(group['service_energy'])
    service_ci = service_sem * t.ppf((1 + confidence_level) / 2, degrees_freedom)
    
    task_mean = group['task_energy'].mean()
    task_sem = sem(group['task_energy'])
    task_ci = task_sem * t.ppf((1 + confidence_level) / 2, degrees_freedom)
    
    total_energy_means.append(total_mean)
    total_energy_cis.append(total_ci)
    service_energy_means.append(service_mean)
    service_energy_cis.append(service_ci)
    task_energy_means.append(task_mean)
    task_energy_cis.append(task_ci)

# Convert to numpy arrays for plotting
data_volume_range = np.array(data_volume_range)
total_energy_means = np.array(total_energy_means)
total_energy_cis = np.array(total_energy_cis)
service_energy_means = np.array(service_energy_means)
service_energy_cis = np.array(service_energy_cis)
task_energy_means = np.array(task_energy_means)
task_energy_cis = np.array(task_energy_cis)

# Plotting bar graph with error bars
fig, ax = plt.subplots(figsize=(12, 8))

width = 0.25  # Width of the bars

# Create bar positions
x = np.arange(len(data_volume_range))
x_total = x - width
x_service = x
x_task = x + width

# Plot bars
ax.bar(x_total, total_energy_means, width, yerr=total_energy_cis, capsize=5, label='Total Energy', alpha=0.7, color='navy', hatch = 'o', edgecolor='black', zorder=3)
ax.bar(x_service, service_energy_means, width, yerr=service_energy_cis, capsize=5, label='Service Energy', alpha=0.7, color='cornflowerblue', hatch = 'x', edgecolor='black', zorder=3)
ax.bar(x_task, task_energy_means, width, yerr=task_energy_cis, capsize=5, label='Task Energy', alpha=0.7, color='thistle', hatch = '/', edgecolor='black', zorder=3)

# Add labels and title
ax.set_xlabel('Data volume (MB)', fontsize=18)
ax.set_ylabel('Energy consumed (Watt-hr)', fontsize=18)
ax.set_xticks(x)
ax.set_xticklabels(data_volume_range)

# Set tick size
plt.xticks(fontsize=14)
plt.yticks(fontsize=14)
plt.grid()

# Create an inset plot
# bbox_to_anchor (x0, y0, width, height) and loc are used for inset position
ax_inset = inset_axes(ax, width="40%", height="40%", bbox_to_anchor=(-0.4, 0.1, 0.8, 0.7), bbox_transform=ax.transAxes)  
ax_inset.bar(x_total, total_energy_means, width, yerr=total_energy_cis, capsize=5, label='Total Energy', alpha=0.7, color='navy', hatch = 'o', edgecolor='black', zorder=2)
ax_inset.bar(x_service, service_energy_means, width, yerr=service_energy_cis, capsize=5, label='Service Energy', alpha=0.7, color='cornflowerblue', hatch = 'x', edgecolor='black', zorder=2)
ax_inset.bar(x_task, task_energy_means, width, yerr=task_energy_cis, capsize=5, label='Task Energy', alpha=0.7, color='thistle', hatch = '/', edgecolor='black', zorder=2)

# Set labels, tick size, and ylim for the inset plot
# ax_inset.set_xlabel('Data Volume Range', fontsize=12)
# ax_inset.set_ylabel('Energy (Joules)', fontsize=12)
print(x)
ax_inset.set_xticks(x)
ax_inset.tick_params(axis='both', which='major', labelsize=10)
ax_inset.set_xticklabels(data_volume_range)
ax_inset.set_ylim(0, 0.15)

# Create a single legend for both plots outside the main plot
handles, labels = ax.get_legend_handles_labels()
fig.legend(handles, labels, loc='upper center', ncol=3, fontsize='x-large', bbox_to_anchor=(0.45, 0.95))

plt.tight_layout()
plt.savefig('energy_consumption_vs_data_volume.pdf', format='pdf', bbox_inches='tight')
plt.show()
