import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from scipy.stats import sem, t
from mpl_toolkits.axes_grid1.inset_locator import inset_axes

plt.rcParams['font.family'] = 'Times New Roman'

# Load the CSV files
df1 = pd.read_csv('energy_consumption_data_volume.csv')
df2 = pd.read_csv('energy_consumption_num_task.csv')
df3 = pd.read_csv('energy_consumption_num_uav.csv')

# Function to calculate means and confidence intervals
def calculate_means_and_cis(df, group_column):
    grouped = df.groupby(group_column)
    means = []
    cis = []
    labels = []
    confidence_level = 0.95
    num_iterations = 100  # Assuming 100 iterations per group
    degrees_freedom = num_iterations - 1
    
    for name, group in grouped:
        labels.append(name)
        
        total_mean = group['total_energy'].mean()
        total_sem = sem(group['total_energy'])
        total_ci = total_sem * t.ppf((1 + confidence_level) / 2, degrees_freedom)
        
        service_mean = group['service_energy'].mean()
        service_sem = sem(group['service_energy'])
        service_ci = service_sem * t.ppf((1 + confidence_level) / 2, degrees_freedom)
        
        task_mean = group['task_energy'].mean()
        task_sem = sem(group['task_energy'])
        task_ci = task_sem * t.ppf((1 + confidence_level) / 2, degrees_freedom)
        
        means.append({
            'total': total_mean,
            'service': service_mean,
            'task': task_mean
        })
        cis.append({
            'total': total_ci,
            'service': service_ci,
            'task': task_ci
        })
    
    return np.array(labels), np.array([m['total'] for m in means]), np.array([c['total'] for c in cis]), \
           np.array([m['service'] for m in means]), np.array([c['service'] for c in cis]), \
           np.array([m['task'] for m in means]), np.array([c['task'] for c in cis])

# Calculate for all dataframes
labels1, total_means1, total_cis1, service_means1, service_cis1, task_means1, task_cis1 = calculate_means_and_cis(df1, 'data_volume_range')
labels2, total_means2, total_cis2, service_means2, service_cis2, task_means2, task_cis2 = calculate_means_and_cis(df2, 'num_task')
labels3, total_means3, total_cis3, service_means3, service_cis3, task_means3, task_cis3 = calculate_means_and_cis(df3, 'num_uav')

# Create a single wide figure with 3 subplots
fig, (ax1, ax2, ax3) = plt.subplots(1, 3, figsize=(18, 5), sharey=True)

# Plot 1
width = 0.25
x1 = np.arange(len(labels1))
x1_total = x1 - width
x1_service = x1
x1_task = x1 + width

ax1.bar(x1_total, total_means1, width, yerr=total_cis1, capsize=5, label='Total Energy', alpha=0.7, color='navy', hatch='o', edgecolor='black', zorder=3)
ax1.bar(x1_service, service_means1, width, yerr=service_cis1, capsize=5, label='Service Energy', alpha=0.7, color='cornflowerblue', hatch='x', edgecolor='black', zorder=3)
ax1.bar(x1_task, task_means1, width, yerr=task_cis1, capsize=5, label='Task Energy', alpha=0.7, color='thistle', hatch='/', edgecolor='black', zorder=3)

ax1.set_xlabel('Data volume (MB)', fontsize=18)
ax1.set_ylabel('Energy consumed (Watt-hr)', fontsize=18)
ax1.set_xticks(x1)
ax1.set_xticklabels(labels1)
ax1.set_ylim(0, 1.5)
ax1.tick_params(axis='both', which='major', labelsize=14)
ax1.grid()

# Inset for plot 1
ax1_inset = inset_axes(ax1, width="60%", height="40%", bbox_to_anchor=(-0.2, 0.2, 0.8, 0.7), bbox_transform=ax1.transAxes)

# Select alternate indices
alternate_indices = np.arange(0, len(x1), 2)

# Wider bar width and spacing
width = 0.4  # Width of each bar
bar_spacing = 0.0  # Space between different categories of bars

# Calculate bar positions for alternate indices with adjusted spacing
x1_total_alt = x1[alternate_indices] - width - bar_spacing
x1_service_alt = x1[alternate_indices]
x1_task_alt = x1[alternate_indices] + width + bar_spacing

# Plot only alternate bars
ax1_inset.bar(x1_total_alt, total_means1[alternate_indices], width, yerr=total_cis1[alternate_indices], capsize=5, label='Total Energy', alpha=0.7, color='navy', hatch='o', edgecolor='black')
ax1_inset.bar(x1_service_alt, service_means1[alternate_indices], width, yerr=service_cis1[alternate_indices], capsize=5, label='Service Energy', alpha=0.7, color='cornflowerblue', hatch='x', edgecolor='black')
ax1_inset.bar(x1_task_alt, task_means1[alternate_indices], width, yerr=task_cis1[alternate_indices], capsize=5, label='Task Energy', alpha=0.7, color='thistle', hatch='/', edgecolor='black')

# Set alternate x-ticks and labels
ax1_inset.set_xticks(x1[alternate_indices])
ax1_inset.set_xticklabels(labels1[alternate_indices])
ax1_inset.set_ylim(0, 0.15)

# Add annotation for subplot (a)
ax1.annotate('(a)', xy=(0.45, -0.25), xycoords='axes fraction', fontsize=18)

# Plot 2
width = 0.25
x2 = np.arange(len(labels2))
x2_total = x2 - width
x2_service = x2
x2_task = x2 + width

ax2.bar(x2_total, total_means2, width, yerr=total_cis2, capsize=5, label='Total Energy', alpha=0.7, color='navy', hatch='o', edgecolor='black', zorder=3)
ax2.bar(x2_service, service_means2, width, yerr=service_cis2, capsize=5, label='Service Energy', alpha=0.7, color='cornflowerblue', hatch='x', edgecolor='black', zorder=3)
ax2.bar(x2_task, task_means2, width, yerr=task_cis2, capsize=5, label='Task Energy', alpha=0.7, color='thistle', hatch='/', edgecolor='black', zorder=3)

ax2.set_xlabel('Number of tasks', fontsize=18)
# ax2.set_ylabel('Energy consumed (Watt-hr)', fontsize=18)
ax2.set_xticks(x2)
ax2.set_xticklabels(labels2)
ax2.set_ylim(0, 0.175)
ax2.tick_params(axis='both', which='major', labelsize=14)
ax2.grid()

# Inset for plot 2
ax2_inset = inset_axes(ax2, width="60%", height="40%", bbox_to_anchor=(-0.2, 0.2, 0.8, 0.7), bbox_transform=ax2.transAxes)  
ax2_inset.bar(x2_total, total_means2, width, yerr=total_cis2, capsize=5, label='Total Energy', alpha=0.7, color='navy', hatch='o', edgecolor='black')
ax2_inset.bar(x2_service, service_means2, width, yerr=service_cis2, capsize=5, label='Service Energy', alpha=0.7, color='cornflowerblue', hatch='x', edgecolor='black')
ax2_inset.bar(x2_task, task_means2, width, yerr=task_cis2, capsize=5, label='Task Energy', alpha=0.7, color='thistle', hatch='/', edgecolor='black')

ax2_inset.set_xticks(x2)
ax2_inset.set_xticklabels(labels2)
ax2_inset.set_ylim(0, 0.175)

# Add annotation for subplot (b)
ax2.annotate('(b)', xy=(0.45, -0.25), xycoords='axes fraction', fontsize=18)

# Plot 3
width = 0.25
x3 = np.arange(len(labels3))
x3_total = x3 - width
x3_service = x3
x3_task = x3 + width

ax3.bar(x3_total, total_means3, width, yerr=total_cis3, capsize=5, label='Total Energy', alpha=0.7, color='navy', hatch='o', edgecolor='black', zorder=3)
ax3.bar(x3_service, service_means3, width, yerr=service_cis3, capsize=5, label='Service Energy', alpha=0.7, color='cornflowerblue', hatch='x', edgecolor='black', zorder=3)
ax3.bar(x3_task, task_means3, width, yerr=task_cis3, capsize=5, label='Task Energy', alpha=0.7, color='thistle', hatch='/', edgecolor='black', zorder=3)

ax3.set_xlabel('Number of UAVs', fontsize=18)
# ax3.set_ylabel('Energy consumed (Watt-hr)', fontsize=18)
ax3.set_xticks(x3)
ax3.set_xticklabels(labels3)
ax3.set_ylim(0, 250)
ax3.tick_params(axis='both', which='major', labelsize=14)
ax3.grid()

# Inset for plot 3
ax3_inset = inset_axes(ax3, width="40%", height="40%", bbox_to_anchor=(-0.5, 0.2, 1.2, 0.7), bbox_transform=ax3.transAxes)  
ax3_inset.bar(x3_total, total_means3, width, yerr=total_cis3, capsize=5, label='Total Energy', alpha=0.7, color='navy', hatch='o', edgecolor='black')
ax3_inset.bar(x3_service, service_means3, width, yerr=service_cis3, capsize=5, label='Service Energy', alpha=0.7, color='cornflowerblue', hatch='x', edgecolor='black')
ax3_inset.bar(x3_task, task_means3, width, yerr=task_cis3, capsize=5, label='Task Energy', alpha=0.7, color='thistle', hatch='/', edgecolor='black')

ax3_inset.set_xticks(x3)
ax3_inset.set_xticklabels(labels3)
ax3_inset.set_ylim(0, 0.10)

# Add annotation for subplot (c)
ax3.annotate('(c)', xy=(0.45, -0.25), xycoords='axes fraction', fontsize=18)

# Create a single legend for all plots outside the main plots
handles, labels = ax1.get_legend_handles_labels()
fig.legend(handles, labels, loc='upper center', ncol=3, fontsize='xx-large', bbox_to_anchor=(0.5, 1.1))

plt.tight_layout()
plt.savefig('energy_consumption_plots.pdf', format='pdf', bbox_inches='tight')
plt.show()
